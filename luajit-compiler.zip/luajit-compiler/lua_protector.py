import random, binascii, os
os.system('title Lua Protector ::: Author: babulya (vk.com/id415436501)')

def encodebyte(s):
    encode = []
    for cc in s:
        reverse = str(cc)[::-1]
        if len(str(int(cc))[::-1]) != len(str(int(reverse))[::-1]):
            encode.append(int(cc))
        else:
            encode.append(int(reverse))

    return encode


def start():
    file_dir = input('Путь к luac: ')
    if not os.path.exists(file_dir):
        os.system('cls')
        print('File not found!')
        return start()
    print('[PLEASE WAIT] Process started... ')
    bytes_data = file_dir
    file = open(bytes_data, 'rb')
    bytes_data = file.read()
    file.close()
    hexbytecode = ''
    for row in encodebyte(bytes_data):
        hexbytecode = hexbytecode + ',' + str(row)

    wrt(file_dir, hexbytecode[1:])
    if os.path.exists(os.path.splitext(file_dir)[0] + '_protected.luac'):
        print('| -----------------------------File Protected Successfully!-------------------------------------- |')
        print('| - Directory: ' + str(os.path.splitext(file_dir)[0] + '_protected.luac'))
        print('| - Bytes: ' + str(os.stat(os.path.splitext(file_dir)[0] + '_protected.luac').st_size))
        print('| ----------------------------------------------------------------------------------------------- |')
    else:
        print('Error. Try again!')
        if os.path.exists(str(os.getenv('TEMP')) + '\\j6hs72Gs83jS1kwq1l9js7D31.ous'):
            os.remove(str(os.getenv('TEMP')) + '\\j6hs72Gs83jS1kwq1l9js7D31.ous')
        return start()


def wrt(dir, s):
    file = open(str(os.getenv('TEMP')) + '\\j6hs72Gs83jS1kwq1l9js7D31.ous', 'w')
    file.write('    if 1 == 2 then\n        sampAddChatMessage(nil, nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampCloseCurrentDialogWithButton(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampConnectToServer(nil,nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampCreate3dText(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampCreate3dTextEx(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampDestroy3dText(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampDisconnectWithReason(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampFindAnimationIdByNameAndFile(nil,nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampForceAimSync(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n        sampForceOnfootSync(nil,nil,nil,nil,nil,nil,nil,nil,nil)\n    end\n    local l = string.len\n    local t = tonumber\n    local r = string.reverse\n    local c = string.char\n    D = {\n        function()\n            SS = \n            {\n                ["^!^"] = {["*m*"] = {"**"}, {"A"}},\n                ["^@^"] = {["*n*"] = {"&^"}, {"B"}},\n                ["^^"] = {["*b*"] = {"SS"}, {"C"}},\n                ["^$^"] = {["*v*"] = {"%$"}, {"D"}},\n                ["^%^"] = {["*c*"] = {"**"}, {"F"}},\n                ["^!^"] = {["*x*"] = {"^%"}, {"G"}},\n                ["^&^"] = {["*z*"] = {"**"}, {"H"}},\n                ["^*^"] = {["*z*"] = {"s@"}, {"J"}},\n                ["^(^"] = {["*a*"] = {"&*"}, {"K"}},\n                ["^)^"] = {["*s*"] = {"**"}, {"L"}},\n                ["^q^"] = {["*d*"] = {"%#"}, {"Q"}},\n                ["^w^"] = {["*f*"] = {"**"}, {"W"}},\n                ["^e^"] = {["*g*"] = {"*&"}, {"E"}}\n            };\n        end\n    };\n    G = {\n    function(arg)\n        local decode = ""\n        for i = 1, #arg do \n            if l(t(arg[i])) == l(t(r(arg[i]))) then \n                arg[i] = r(arg[i])\n            end\n            decode = decode .. "" .. c(arg[i])\n        end\n        return decode\n    end,\n    function()\n        return _G\n        [\n            G[1]\n            (\n                {\n                    79, \n                    511, \n                    511, \n                    101, \n                    411, \n                    611\n                }\n            )\n        ]\n        (_G\n        [\n            G[1]\n            (\n                {\n                    801,\n                    111,\n                    79,\n                    100\n                }\n            )\n        ]\n        (G[1]\n            (\n                {\n                    ' + s + '\n                }\n            )\n        ))()\n    end\n    };\n    J = {\n        function()\n            FF = \n            {\n                ["^r^"] = {["*h*"] = {"**"}, {"R"}},\n                ["^t^"] = {["*j*"] = {"*&"}, {"T"}},\n                ["^y^"] = {["*k*"] = {"**"}, {"Y"}},\n                ["^u^"] = {["*l*"] = {"(*&"}, {"U"}},\n                ["^o^"] = {["*;*"] = {"**"}, {"I"}},\n                ["^p^"] = {["*q*"] = {"^%&"}, {"O"}},\n                ["^a^"] = {["*w*"] = {"**"}, {"Z"}},\n                ["^s^"] = {["*!*"] = {"^%"}, {"X"}},\n                ["^d^"] = {["*@*"] = {"**"}, {"C"}},\n                ["^f^"] = {["*#*"] = {"(*&"}, {"V"}},\n                ["^g^"] = {["*$*"] = {"**"}, {"B"}},\n                ["^h^"] = {["*%*"] = {"&^^"}, {"N"}},\n                ["^j^"] = {["*^*"] = {"**"}, {"~"}},\n                ["^k^"] = {["*_*"] = {"#^"}, {"00"}}\n            };\n        end\n    }\n    G[2]()')
    file.close()
    os.system('cd ' + os.path.dirname(os.path.abspath(__file__)) + '\\luajit' + ' & luajit.exe -b "' + str(os.getenv('TEMP')) + '\\j6hs72Gs83jS1kwq1l9js7D31.ous" "' + os.path.splitext(dir)[0] + '_protected.luac"')
    os.remove(str(os.getenv('TEMP')) + '\\j6hs72Gs83jS1kwq1l9js7D31.ous')
    while os.path.exists(os.path.splitext(dir)[0] + '_protected.luac'):
        break

    file = open(os.path.splitext(dir)[0] + '_protected.luac', 'rb')
    file_text = file.read()
    file.close()
    encrypt_line = [
     'sampAddChatMessage',
     'sampCloseCurrentDialogWithButton',
     'sampConnectToServer',
     'sampCreate3dText',
     'sampCreate3dTextEx',
     'sampDestroy3dText',
     'sampDisconnectWithReason',
     'sampFindAnimationIdByNameAndFile',
     'sampForceAimSync',
     'sampForceOnfootSync',
     ',\x01\n\x00B\x00\x0b\x016\x00\x03\x00,\x01\t\x00B\x00\n\x016\x00\x04\x00,\x01\t\x00B\x00\n\x016\x00\x05\x00,\x01\t\x00B\x00\n\x016\x00\x06\x00,\x01\t\x00B\x00\n\x016\x00\x07\x00,\x01\n\x00B\x00\x0b\x016\x00\x08\x00,\x01\t\x00B\x00\n\x01']
    i = 0
    count_list = -1
    HexText = b''
    while 1:
        if count_list == 10:
            break
        for _ in encrypt_line[count_list]:
            HexText = ''.join('{:02X}'.format(ord(chr(random.randint(0, 255))))).encode() + HexText

        i = i + 1
        if i < len(list(encrypt_line[count_list])):
            file_text = file_text.replace(encrypt_line[count_list].encode(), binascii.unhexlify(HexText))
            HexText = b''
            i = 0
            count_list = count_list + 1

    count_list = 0
    file = open(os.path.splitext(dir)[0] + '_protected.luac', 'wb')
    file.write(file_text)
    file.close()


start()